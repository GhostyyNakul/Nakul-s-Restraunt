import { Order } from '../types';

/**
 * Sends a highly styled invoice email to the customer using Gmail API
 */
export async function sendOrderInvoiceEmail(
  accessToken: string,
  order: Order
): Promise<boolean> {
  if (!order.customerEmail) {
    console.warn("Unable to send invoice: Order does not contain customer email.");
    return false;
  }

  const subject = `Nakul's Restraunt Invoice - Order ${order.id} 🍕`;
  const htmlContent = generateInvoiceHtml(order);

  try {
    // Construct standard RFC 2822 MIME message
    const mimeParts = [
      `To: ${order.customerEmail}`,
      `Subject: =?utf-8?B?${btoa(unescape(encodeURIComponent(subject)))}?=`,
      `MIME-Version: 1.0`,
      `Content-Type: text/html; charset="UTF-8"`,
      ``,
      htmlContent
    ];

    const rawMime = mimeParts.join('\r\n');
    
    // safe base64url encoding
    const encodedMime = btoa(unescape(encodeURIComponent(rawMime)))
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');

    const response = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        raw: encodedMime
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('Failed to send invoice via Gmail:', errorData);
      return false;
    }

    console.log(`Invoice email sent successfully to ${order.customerEmail}`);
    return true;
  } catch (error) {
    console.error('Error in sendOrderInvoiceEmail:', error);
    return false;
  }
}

function generateInvoiceHtml(order: Order): string {
  const itemsRows = order.items.map(item => `
    <tr>
      <td style="padding: 12px 0; border-bottom: 1px solid #eeeeee; font-family: 'Sora', 'Inter', sans-serif; font-size: 14px; font-weight: 500; color: #111111;">
        ${item.name}
        <span style="display: block; font-size: 11px; color: #888888; font-family: monospace;">Qty: ${item.quantity} x ₹${item.price}</span>
      </td>
      <td align="right" style="padding: 12px 0; border-bottom: 1px solid #eeeeee; font-family: monospace; font-size: 14px; font-weight: bold; color: #ff5c00;">
        ₹${item.price * item.quantity}
      </td>
    </tr>
  `).join('');

  const paymentLabel = order.paymentMethod === 'cod' ? 'Cash on Delivery 💵' : 'Online UPI/Card Paid 💳';

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Your Nakul's Restraunt Receipt</title>
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;600;800&family=Space+Grotesk:wght@500;700&display=swap');
      </style>
    </head>
    <body style="margin: 0; padding: 0; background-color: #f7f6f5; -webkit-text-size-adjust: none; text-size-adjust: none;">
      <table border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color: #f7f6f5; padding: 40px 10px;">
        <tr>
          <td align="center">
            
            <!-- Outer Card Container -->
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 550px; background-color: #ffffff; border-radius: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.04); overflow: hidden; border: 1px solid #eae2db;">
              
              <!-- Fire Head Banner -->
              <tr>
                <td style="background-color: #111111; padding: 30px 40px; text-align: center; border-bottom: 5px solid #ff5c00;">
                  <h1 style="margin: 0; color: #ffffff; font-family: 'Space Grotesk', sans-serif; font-size: 28px; font-weight: 700; tracking: -0.5px;">
                    NAKUL'S <span style="color: #ff5c00;">RESTRAUNT</span>
                  </h1>
                  <p style="margin: 5px 0 0 0; color: #888888; font-family: 'Sora', sans-serif; font-size: 11px; letter-spacing: 2px; text-transform: uppercase; font-weight: bold;">
                    culinary intensity defined
                  </p>
                </td>
              </tr>

              <!-- Greeting & Header -->
              <tr>
                <td style="padding: 40px 40px 15px 40px;">
                  <h2 style="margin: 0; font-family: 'Space Grotesk', sans-serif; font-size: 22px; font-weight: 700; color: #111111;">
                    Hey ${order.customerName},
                  </h2>
                  <p style="margin: 10px 0 0 0; font-family: 'Sora', sans-serif; font-size: 13px; line-height: 1.6; color: #555555;">
                    Your oven-baked fire is officially sparked! Below is the verified invoice logs copy for your Nakul's Restraunt order placed at Delhi, India.
                  </p>
                </td>
              </tr>

              <!-- Invoice details summary -->
              <tr>
                <td style="padding: 0 40px;">
                  <table border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color: #faf8f7; border-radius: 14px; padding: 15px; border-left: 4px solid #ff5c00;">
                    <tr>
                      <td style="font-family: 'Sora', sans-serif; font-size: 11px; color: #777777; font-weight: bold; text-transform: uppercase;">Order ID</td>
                      <td align="right" style="font-family: monospace; font-size: 13px; color: #ff5c00; font-weight: bold;">${order.id}</td>
                    </tr>
                    <tr>
                      <td style="font-family: 'Sora', sans-serif; font-size: 11px; color: #777777; font-weight: bold; text-transform: uppercase; padding-top: 5px;">Date &amp; Time</td>
                      <td align="right" style="font-family: monospace; font-size: 12px; color: #111111; padding-top: 5px;">${order.date} @ ${order.time || 'Pending'}</td>
                    </tr>
                    <tr>
                      <td style="font-family: 'Sora', sans-serif; font-size: 11px; color: #777777; font-weight: bold; text-transform: uppercase; padding-top: 5px;">Payment</td>
                      <td align="right" style="font-family: 'Sora', sans-serif; font-size: 12px; color: #111111; font-weight: bold; padding-top: 5px;">${paymentLabel}</td>
                    </tr>
                  </table>
                </td>
              </tr>

              <!-- Items table -->
              <tr>
                <td style="padding: 30px 40px 10px 40px;">
                  <h3 style="margin: 0 0 10px 0; font-family: 'Space Grotesk', sans-serif; font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: #777777; border-bottom: 2px solid #ff5c00; padding-bottom: 5px;">
                    Order Content
                  </h3>
                  <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    ${itemsRows}
                  </table>
                </td>
              </tr>

              <!-- Grand Total box -->
              <tr>
                <td style="padding: 0 40px 30px 40px;">
                  <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                      <td style="font-family: 'Space Grotesk', sans-serif; font-size: 16px; font-weight: 700; color: #111111;">Total Invoice Amount</td>
                      <td align="right" style="font-family: monospace; font-size: 20px; font-weight: 900; color: #ff5c00;">₹${order.totalAmount}</td>
                    </tr>
                  </table>
                </td>
              </tr>

              <!-- Delivery Address block -->
              <tr>
                <td style="padding: 0 40px 30px 40px;">
                  <table border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color: #fefef2; border-radius: 14px; padding: 15px; border: 1px dashed #eedccb;">
                    <tr>
                      <td style="font-family: 'Sora', sans-serif; font-size: 11px; color: #777777; font-weight: bold; text-transform: uppercase; padding-bottom: 6px;">Delivery Destination</td>
                    </tr>
                    <tr>
                      <td style="font-family: 'Sora', sans-serif; font-size: 12px; line-height: 1.5; color: #333333; font-weight: 500;">
                        ${order.address}<br>
                        <span style="font-size: 11px; color: #666666; font-family: monospace;">Phone: ${order.customerPhone}</span>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>

              <!-- Footer with greetings -->
              <tr>
                <td style="padding: 30px 40px; background-color: #fafcfb; text-align: center; border-top: 1px solid #eeeeee;">
                  <p style="margin: 0; font-family: 'Space Grotesk', sans-serif; font-weight: bold; font-size: 13px; color: #ff5c00;">
                    Thank you for ordering with culinary density ! 🔥
                  </p>
                  <p style="margin: 6px 0 0 0; font-family: 'Sora', sans-serif; font-size: 11px; color: #888888;">
                    Nakul's Restraunt Delhi, India &middot; oven stoked at absolute intensity.
                  </p>
                </td>
              </tr>

            </table>

            <p style="margin-top: 25px; font-family: 'Sora', sans-serif; font-weight: 500; font-size: 11px; color: #999999; text-align: center;">
              This is a secure automated receipt generated for ghostnakul4@gmail.com
            </p>

          </td>
        </tr>
      </table>
    </body>
    </html>
  `;
}
