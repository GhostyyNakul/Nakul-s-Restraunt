import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

// Load environment variables from .env and .env.example
dotenv.config();
dotenv.config({ path: path.join(process.cwd(), ".env.example") });

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Add JSON parsing middleware
  app.use(express.json());

  // API routes FIRST
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // POST endpoint for Primary Telnyx Webhook (Inbound SMS, Delivery Reports, etc.)
  app.post("/api/telnyx-webhook", async (req, res) => {
    console.log("=== RECEIVED TELNYX PRIMARY WEBHOOK ===");
    console.log(JSON.stringify(req.body, null, 2));
    
    // Process Event if present
    const event = req.body?.data;
    if (event) {
      console.log(`Event Type: ${event.event_type}`);
      const payload = event.payload;
      if (payload) {
        console.log(`Payload Message ID: ${payload.id}`);
        console.log(`Direction: ${payload.direction}`);
        
        // Check for inbound SMS to handle interactive commands
        if (event.event_type === "message.received" && payload.direction === "inbound") {
          const rawText = (payload.text || "").trim();
          const lowerText = rawText.toLowerCase();
          const fromNumber = payload.from?.phone_number;
          
          if (fromNumber) {
            console.log(`Received inbound SMS from ${fromNumber} with body: "${rawText}"`);
            
            // Keyword: HELP
            if (lowerText === "help") {
              const helpReply = `🍔 NAKUL'S RESTRAUNT SUPPORT 🍟\n\n` +
                `Need assistance? Standard command options:\n` +
                `• Text MENU to view current gourmet specials.\n` +
                `• Text ORDER to check delivery radius.\n` +
                `• Support contact: ghostnakul4@gmail.com\n\n` +
                `Reply STOP to opt out of order updates. Msg & Data rates may apply. Visit us at Yamuna Vihar, Delhi!`;
                
              sendSMS(fromNumber, helpReply).then(result => {
                console.log(`Auto-response HELP sent to ${fromNumber}. MsgId: ${result.messageId}`);
              }).catch(err => {
                console.error(`Failed to dispatch auto-response HELP to ${fromNumber}:`, err.message);
              });
            }
            
            // Keyword: MENU
            else if (lowerText === "menu") {
              const menuReply = `🍔 NAKUL'S RESTRAUNT SHED MENU 🍕\n\n` +
                `• Classic Veg Burger: ₹129\n` +
                `• Loaded Crust Pizza: ₹349\n` +
                `• Mint Lemon Mojito: ₹99\n` +
                `• Extreme Combo Feast: ₹499\n\n` +
                `Order online right here in this web app for hot 10-minute dispatch! Yamuna Vihar, Delhi.`;
                
              sendSMS(fromNumber, menuReply).then(result => {
                console.log(`Auto-response MENU sent to ${fromNumber}. MsgId: ${result.messageId}`);
              }).catch(err => {
                console.error(`Failed to dispatch auto-response MENU to ${fromNumber}:`, err.message);
              });
            }
          }
        }
      }
    }
    console.log("========================================");
    
    // Respond with 200 OK to acknowledge receipt
    res.status(200).json({ status: "processed" });
  });

  // POST endpoint for Failover Telnyx Webhook
  app.post("/api/telnyx-webhook-failover", async (req, res) => {
    console.warn("=== RECEIVED TELNYX FAILOVER WEBHOOK ===");
    console.warn(JSON.stringify(req.body, null, 2));
    
    const event = req.body?.data;
    if (event) {
      console.warn(`[FAILOVER] Event Type: ${event.event_type}`);
      const payload = event.payload;
      if (payload) {
        console.warn(`[FAILOVER] Payload Message ID: ${payload.id}`);
        
        // Handle help commands in failover if needed
        if (event.event_type === "message.received" && payload.direction === "inbound") {
          const rawText = (payload.text || "").trim();
          const lowerText = rawText.toLowerCase();
          const fromNumber = payload.from?.phone_number;
          
          if (fromNumber && lowerText === "help") {
            const helpReply = `🍔 NAKUL'S RESTRAUNT [FAILOVER UTILITY]\n\nType MENU to get our list of gourmet options or visit our portal at Yamuna Vihar. Text STOP to opt out.`;
            sendSMS(fromNumber, helpReply).catch(err => console.error(`Failover auto-reply failed:`, err.message));
          }
        }
      }
    }
    console.warn("========================================");
    
    res.status(200).json({ status: "failover_processed" });
  });

  // Diagnostic Logs for Telnyx Environment Variables on Bootup
  const loadedApiKey = process.env.TELNYX_API_KEY || "";
  const maskedKey = loadedApiKey.length > 8 
    ? `${loadedApiKey.substring(0, 6)}...${loadedApiKey.substring(loadedApiKey.length - 4)}` 
    : (loadedApiKey ? "Present but too short" : "Not configured");
  
  console.log("=========================================");
  console.log("TELNYX ENVIRONMENT DIAGNOSTICS:");
  console.log("TELNYX_API_KEY:", maskedKey);
  console.log("TELNYX_PHONE_NUMBER:", process.env.TELNYX_PHONE_NUMBER || "Not configured");
  console.log("=========================================");

  // Reusable function to send SMS via Telnyx API
  async function sendSMS(to: string, message: string): Promise<{ success: boolean; messageId?: string }> {
    const apiKey = process.env.TELNYX_API_KEY;
    const fromNumber = process.env.TELNYX_PHONE_NUMBER;

    if (!apiKey || !fromNumber) {
      throw new Error('Telnyx credentials (TELNYX_API_KEY, TELNYX_PHONE_NUMBER) are not configured.');
    }

    const cleanKey = apiKey.trim();
    if (
      cleanKey.startsWith("YOUR_") || 
      cleanKey === "your_key_here" || 
      cleanKey === "placeholder" || 
      cleanKey.length < 15
    ) {
      throw new Error('Default placeholder TELNYX_API_KEY detected. Please configure a valid active key.');
    }

    const response = await fetch("https://api.telnyx.com/v2/messages", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${cleanKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: fromNumber,
        to: to,
        text: message
      })
    });

    if (response.status === 401) {
      throw new Error('Authentication failed: Your TELNYX_API_KEY is incorrect, inactive, or has expired.');
    }

    if (response.status === 403) {
      throw new Error('Forbidden: Telnyx rejected the request (check account balance or credentials permissions).');
    }

    const data = await response.json();

    if (response.ok) {
      return { success: true, messageId: data.data?.id };
    } else {
      const errorMsg = data.errors?.[0]?.title || data.errors?.[0]?.detail || "Telnyx API error";
      throw new Error(errorMsg);
    }
  }

  // POST endpoint to trigger automated real-world Telnyx SMS confirmation
  app.post("/api/send-sms", async (req, res) => {
    const { orderId, customerName, customerPhone, itemsSummary, totalAmount } = req.body;

    const apiKey = process.env.TELNYX_API_KEY;
    const phoneFrom = process.env.TELNYX_PHONE_NUMBER;

    const isPlaceholderKey = (val?: string) => {
      if (!val) return true;
      const v = val.trim().toLowerCase();
      return v.startsWith("your_") || v === "placeholder" || v.length < 15;
    };

    const isPlaceholderPhone = (val?: string) => {
      if (!val) return true;
      const v = val.trim().toLowerCase();
      return v.startsWith("your_") || v === "placeholder" || v.length < 7;
    };

    if (isPlaceholderKey(apiKey) || isPlaceholderPhone(phoneFrom)) {
      return res.status(200).json({
        success: false,
        reason: 'credentials_missing',
        message: 'Telnyx credentials (TELNYX_API_KEY, TELNYX_PHONE_NUMBER) are not configured, or a default placeholder is being used.'
      });
    }

    // Format phone number safely. Telnyx / E.164 expects +[countrycode][number] (e.g. +91XXXXXXXXXX)
    let formattedPhone = customerPhone.replace(/\s+/g, '').trim();
    if (!formattedPhone.startsWith('+')) {
      // Default to India prefix (+91) if it's a 10-digit number
      if (formattedPhone.length === 10) {
        formattedPhone = '+91' + formattedPhone;
      } else {
        // Fallback prefix
        formattedPhone = '+' + formattedPhone;
      }
    }

    const messageText = `🍔 NAKUL'S RESTRAUNT - ORDER CONFIRMED 🍟\n\n` +
      `Hello, ${customerName}!\n` +
      `We have received your order at Nakul's Restraunt. Your premium gourmet treats are being processed!\n\n` +
      `Order Ticket:\n` +
      `• Order ID: ${orderId}\n` +
      `• Items: ${itemsSummary}\n` +
      `• Total: ₹${totalAmount}\n\n` +
      `Preparation & Delivery Info:\n` +
      `Our kitchen is firing up! Estimated response and dispatch time is 5-10 minutes.\n\n` +
      `Join the Feast! Standard Delivery at Yamuna Vihar, Delhi. Thank you for choosing us!`;

    try {
      const result = await sendSMS(formattedPhone, messageText);
      return res.status(200).json({
        success: true,
        messageId: result.messageId,
        message: 'Automated Telnyx SMS message dispatched successfully!'
      });
    } catch (error: any) {
      console.error('Error invoking Telnyx SMS API:', error);
      return res.status(200).json({
        success: false,
        reason: 'telnyx_rejected',
        message: error.message || 'Telnyx API rejected the request. Please verify the API key, from number, and destination format.',
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
